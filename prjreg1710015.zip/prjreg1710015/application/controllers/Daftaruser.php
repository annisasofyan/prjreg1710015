<?php
 class Daftaruser extends CI_Controller 
 { 
 	public function __construct()
 	 { 
 	 	parent::__construct();
 	 	 if
 	 	  ($this->session->userdata('login') == TRUE && $this->session->userdata('idlevel') == 1)
 	  	{ 
 	 	   	$this->load->model('Modeldaftaruser', 'daftar'); 
 	 	   	return true; 
 	 	   } else {
 	 	    redirect('login/keluar', 'refresh'); 
 	 	}
 	  }
 	  public function index()
 	  {
 	 	   $data = array(
 	 	    'tampildata' => $this->daftar->datauserregistrasi() );
 	 	     $parser = array(
 	 	       'menu' => $this->load->view('home/menu', '', true),
 	 	       'judul' => 'Daftar User Registrasi',
 	 	       'isi' => $this->load->view('daftaruser/viewdata', $data, true),
 	 	        ); 
 	 	     $this->parser->parse('home/layout', $parser);
 	 }

 	 public function detail()
 	  { 
 	  	$id = $this->uri->segment(3); 
 	  	$ambildata = $this->daftar->ambildatauser($id); 
 	  	if ($ambildata->num_rows() > 0) { 
 	  			$row = $ambildata->row_array(); 
 	  			$data = array( 
 	  				'idreg' => $id, 
 	  				'tglreg' => $row['regtgl1710015'], 
 	  				'nama' => $row['regnama1710015'], 
 	  				'jk' => $row['regjk1710015'], 
 	  				'ttl' => $row['regtmplahir1710015'] . '/' . $row['regtgllahir1710015'], 
 	  				'email' => $row['regemail1710015'], 
 	  				'alamat' => $row['regalamat1710015'], 
 	  				'foto' => $row['regfoto1710015'], 
 	  				'status' => $row['regstatus1710015'] ); 
 	  			$parser = array( 
 	  				'menu' => $this->load->view('home/menu', '', true), 
 	  				'judul' => 'Detail User', 
 	  				'isi' => $this->load->view('daftaruser/viewdatadetail', $data, true), 
 	  				); 
 	  			$this->parser->parse('home/layout', $parser); 
 	  		} else { 
 	  			exit('Data tidak ditemukan'); 
 	  		} 
 	  	}
 	  	public function updatestatus()
 	  	{
 	  		$id =$this->uri->segment(3);
 	  		$ambildata =$this->daftar->ambildatauser($id);	
 	  		if ($ambildata->num_rows() > 0) {
 	  			$row=$ambildata->row_array();
 	  			$status = $row['regstatus1710015'];
 	  			$this->daftar->updatestatususer($id,$status);
 	  			redirect('daftaruser/detail/' .$id);
 	  		} else{
 	  			exit('Data Tidak Ditemukan');
 	  		}
 	  	}
 	  
 }
 ?>