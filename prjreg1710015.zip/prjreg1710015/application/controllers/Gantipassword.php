<?php 
class Gantipassword extends CI_Controller 
{ 
	public function __construct() 
	{ parent::__construct(); 
		if 
			($this->session->userdata('login') == TRUE) 
		{ 
			return true; 
		} else { 
			redirect('login/index', 'refresh'); 
		} 
	} public function index() 
	{ 
		$parser = array( 
			'menu' => $this->load->view('home/menu', '', true), 
			'judul' => 'Ganti Password',
			'isi' => $this->load->view('gantipassword/viewform', '', true), 
			); 
		$this->parser->parse('home/layout', $parser); 
	} 
	function update() 
	{ 
		$passlama = $this->input->post('passlama', true); 
		$passbaru = $this->input->post('passbaru', true); 
		$ulangi = $this->input->post('ulangipassbaru', true); 
		$this->load->library('form_validation'); 
		$this->form_validation->set_rules('passlama', 'Password Lama', 'trim|required', array( 
		'required' => '%s tidak boleh kosong' 
		)); 
		$this->form_validation->set_rules('passbaru', 'Password Baru', 'trim|required', array( 
		'required' => '%s tidak boleh kosong' 
		)); 
		$this->form_validation->set_rules(
		'ulangipassbaru', 
		'Ulangi Password Baru', 
		'trim|required|matches[passbaru]', array( 
		'required' => '%s tidak boleh kosong', 
		'matches' => 'Inputan %s harus sama' 
		)); 
		if 
			($this->form_validation->run() == TRUE) 
			{ 
			//cek terlebih dahulu apakah yang login adalah hak akses level 1 atau 2 
			$idlevel = $this->session->userdata('idlevel'); 
			$iduser = $this->session->userdata('iduser'); 
			if 
			($idlevel == 1) 
			{ 
			//cek password lama untuk level 1 atau user admin 
			$query_ambildata_admin = $this->db->get_where('admin1710015', array(
			'adminid1710015' => $iduser)); 
			$row_admin = $query_ambildata_admin->row_array(); 
			$pass_admin = $row_admin['adminpassword1710015']; 
			if (password_verify($passlama, $pass_admin)) 
				{ 
				//update password untuk hak akses admin 
					$hash_passbaruadmin = password_hash($passbaru, PASSWORD_BCRYPT); 
					$dataupdate_admin = array( 
						'adminpassword1710015' => $hash_passbaruadmin ); 
					$this->db->where('adminid1710015', $iduser); 
					$this->db->update('admin1710015', $dataupdate_admin); 
					$pesan = '<div class="alert alert-success alert-dismissible fade show" role="alert"> 
					<h4 class="alert-heading">Berhasil
					</h4><hr> 
					Password anda berhasil diganti, silahkan login kembali 
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"> 
					<span aria-hidden="true">&times;
					</span>
					</button> </div>'; 
					$this->session->set_flashdata('pesan', $pesan); 
					redirect('login/index', 'refresh'); 
					} else { 
					$pesan = '<div class="alert alert-danger alert-dismissible fade show" role="alert"> 
					<h4 class="alert-heading">Error
					</h4><hr> 
					Password lama anda salah, silahkan ulangi kembali 
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"> 
					<span aria-hidden="true">&times;
					</span> </button> </div>'; 
					$this->session->set_flashdata('pesan', $pesan); 
					redirect('gantipassword/index', 'refresh'); 
					} 
				} 
					if ($idlevel == 2) 
						{ 
						//cek password lama untuk level 2 
							$query_ambildata_user = $this->db->get_where('reg1710015', array('reguserid1710015' => $iduser)); 
							$row_user = $query_ambildata_user->row_array(); 
							$pass_user = $row_user['regpass1710015']; 
							if (password_verify($passlama, $pass_user)) 
							{ 
							//update password untuk hak akses user 
								$hash_passbaru_user = password_hash($passbaru, PASSWORD_BCRYPT); 
								$dataupdate_user = array( 'regpass1710015' => $hash_passbaru_user ); 
								$this->db->where('reguserid1710015', $iduser); 
								$this->db->update('reg1710015', $dataupdate_user); 
								$pesan = '<div class="alert alert-success alert-dismissible fade show" role="alert"> 
								<h4 class="alert-heading">Berhasil
								</h4><hr> 
								Password anda berhasil diganti, silahkan login kembali 
								<button type="button" class="close" data-dismiss="alert" aria-label="Close"> 
								<span aria-hidden="true">&times;
								</span> </button> </div>'; 
								$this->session->set_flashdata('pesan', $pesan); 
								redirect('login/index', 'refresh'); 
							} else { 
								$pesan = '<div class="alert alert-danger alert-dismissible fade show" role="alert"> 
								<h4 class="alert-heading">Error
								</h4><hr> 
								Password lama anda salah, silahkan ulangi kembali 
								<button type="button" class="close" data-dismiss="alert" aria-label="Close"> 
								<span aria-hidden="true">&times;
								</span> </button> </div>'; 
								$this->session->set_flashdata('pesan', $pesan); 
								redirect('gantipassword/index', 'refresh'); 
							} 
						} 
					} else { 
						$pesan = '<div class="alert alert-danger alert-dismissible fade show" role="alert"> 
						<h4 class="alert-heading">Error
						</h4><hr> ' . validation_errors() . ' 
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"> 
						<span aria-hidden="true">&times;
						</span> </button> </div>'; 
						$this->session->set_flashdata('pesan', $pesan); 
						redirect('gantipassword/index', 'refresh'); 
					} 
				}
				
}
?>