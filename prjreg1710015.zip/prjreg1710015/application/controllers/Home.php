<?php 
class Home extends CI_controller
{
	 public function __construct()
	 {
	 	 parent::__construct();
	 	 if($this->session->userdata('login') == TRUE)
	 	 {
	 	 	return true;
	 	 }else{
	 	 	redirect('login/index','refresh');
	 	 }
	 }
	 public function index()
	 {
	 	$parser=array(
	 		'menu' =>$this->load->view('home/menu','',true),
	 		'judul' => 'selamat datang  '. $this->session->userdata('iduser'),
	 		'isi' => $this->load->view('home/beranda','',true),
	 		);
	 	$this->parser->parse('home/layout',$parser);
	 }
}

?>