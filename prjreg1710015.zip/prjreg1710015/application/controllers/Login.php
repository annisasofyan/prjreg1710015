<?php 
class Login extends CI_Controller{
	public function __construct()
	{
		parent::__construct();
		 $this->load->library('form_validation');
        $this->load->model('Modellogin','login');
	}
	function index()
	{
		$view = array(
			'isi' => $this->load->view('login/formlogin','',true));
		$this->parser->parse('reg/viewform', $view);
	}
	// function buatpass()
	// {
	// 	echo password_hash('admin', PASSWORD_BCRYPT);
	// }
	function cekuser() {
		$iduser = $this->input->post('iduser', true); 
	 	$passuser = $this->input->post('passuser', true);
	  	$this->form_validation->set_rules('iduser', 'ID User', 'trim|required', array( 
	  	'required' => '%s tidak boleh kosong' )
	  ); 
	  	$this->form_validation->set_rules('passuser', 'Password', 'trim|required', array(
	   'required' => '%s tidak boleh kosong' )
	  );

	  	 if ($this->form_validation->run() == true) { 
	//Buat query untuk cek user ditabel admin dan di tabel registrasi user terlebih dahulu
	 		$querycek_admin = $this->login->cekuseradmin($iduser);
	 	 	$querycek_reg = $this->login->cekuserregistrasi($iduser);

	  	 if ($querycek_admin->num_rows() > 0 || $querycek_reg->num_rows() > 0) { 
	   //cek password untuk tabel admin
	    	$row_admin = $querycek_admin->row_array();
	     	$pass_admin_hash = $row_admin['adminpassword1710015']; 
	     //cek password untuk tabel registrasi
	      	$row_registrasi = $querycek_reg->row_array();
	       	$pass_user_hash = $row_registrasi['regpass1710015']; 
	   	 if (password_verify($passuser, $pass_admin_hash)) {
	        $simpan_session = array( 
	        	'iduser' => $iduser,
	        	'namauser' => $row_admin['adminnama1710015'],
	        	'idlevel' => $row_admin['adminlevelid1710015'], 
	        	'login' => TRUE 
	        	  );

	   	   } else if (password_verify($passuser, $pass_user_hash)) {
	        	   $simpan_session = array( 
	        	    	'iduser' => $iduser,
	        	    	'namauser' => $row_registrasi['regnama1710015'], 
	        	    	'idlevel' => $row_registrasi['reglevelid1710015'], 
	        	    	'login' => TRUE,
	        	    	'fotouser' => $row_registrasi['regfoto1710015'],
	        	    	 );
	        } else {
	        	   	$pesan = '<div class="alert alert-danger alert-dismissible fade show" role="alert"> 
	        	    	 <h4 class="alert-heading">Maaf</h4><hr> Password Anda Salah 
	        	    	 <button type="button" class="close" data-dismiss="alert" aria-label="Close"> 
	        	    	 <span aria-hidden="true">&times;</span> 
	        	    	 </button> 
	        	    	</div>';
	        	    $this->session->set_flashdata('pesan', $pesan);
	        	    redirect('login/index', 'refresh');
	       	    }
	    $this->session->set_userdata($simpan_session);
    	  if ($this->session->userdata('login') == TRUE)
	        { 
	        	redirect('home/index', 'refresh'); 
	       	} else {
	        	redirect('login/index', 'refresh');
	        } 
	       } else {
	        	$pesan = '<div class="alert alert-danger alert-dismissible fade show" role="alert"> 
	        	<h4 class="alert-heading">Maaf</h4><hr> User yang anda inputkan tidak ditemukan pada database kami
	        	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
	        	<span aria-hidden="true">&times; </span> 
	        </button> 
	       </div>'; 
	        	$this->session->set_flashdata('pesan', $pesan);
	        	 redirect('login/index', 'refresh');
	        	    }
	        	  } else { 
	        	    $pesan = '<div class="alert alert-danger alert-dismissible fade show" role="alert">
	       	           	 <h4 class="alert-heading">Error</h4><hr> ' . validation_errors() . '
	        	    	 <button type="button" class="close" data-dismiss="alert" aria-label="Close"> 
	        	    	 <span aria-hidden="true">&times;</span> 
	        	    	 </button> 
	        	    	</div>';
	        	    $this->session->set_flashdata('pesan', $pesan); 
	        	   redirect('login/index', 'refresh');
	        	  }
	    		}
	    function keluar()
	    {
	    	$this->session->sess_destroy();
	    	redirect('login/index','refresh');
	    }
	    function lupapassword()
	    {
	    	$view = array(
	    		'isi' => $this->load->view('login/formlupapassword','',true)
	    		);
	    	$this->parser->parse('reg/viewform',$view);
	    }
	    function kirimemail() 
	    { 
	    	$email = $this->input->post('emailuser', true); 
	    	$this->load->library(array('form_validation', 'encryption')); 
	    	$this->form_validation->set_rules('emailuser', 'Alamat Email', 'trim|required|valid_email', array( 
	    	'required' => '%s tidak boleh kosong', 
	    	'valid_email' => 'Inputan %s harus valid' 
	    	)); 
	    		if ($this->form_validation->run() == TRUE) 
	    		{ 
	    		//cek email di tabel reg 
	    		$querycek = $this->db->get_where('reg1710015', array(
	    		'regemail1710015' => $email
	    		)); 
	    		if ($querycek->num_rows() > 0) { 
	    		$row = $querycek->row_array(); 
	    		$iduser = $row['reguserid1710015']; 
	    		$namauser = $row['regnama1710015']; 
	    		// Konfigurasi email 
	    		$config = array( 
	    		'mailtype' => 'html', 
	    		'charset' => 'utf-8', 
	    		'protocol' => 'smtp', 
	    		'smtp_host' => 'smtp.gmail.com', 
	    		'smtp_user' => 'annisa.sofyan30', // Email gmail
	    		 'smtp_pass' => 'islahramadhan', // Password gmail 
	    		 'smtp_crypto' => 'ssl', 
	    		 'smtp_port' => 465, 
	    		 'crlf' => "\r\n", 
	    		 'newline' => "\r\n" 
	    		 ); 
	    		 // Load library email dan konfigurasinya 
	    		 $this->load->library('email', $config); 
	    		 // Email dan nama pengirim 
	    		 $this->email->from('no-reply@annisa.com', 'Annisa'); //Ganti saja dengan nama anda 
	    		 // Email penerima 
	    		 $this->email->to($email); // Ganti dengan email tujuan 
	    		 // Subject email 
	    		 $this->email->subject('Reset Password | Annisa.com'); 
	    		 // Isi email 
	    		 $linkverifikasi_iduser = urlencode(base64_encode($this->encryption->encrypt($iduser))); 
	    		 $datauser = array( 
	    		 	'namalengkap' => $namauser, 
	    		 	'iduser' => $iduser,
	    		 	'linkverifikasi' => site_url() . '/login/formpasswordbaru/' . $linkverifikasi_iduser ); 
	    		 	$isiemail = $this->load->view('login/isiemaillupapassword', $datauser, true); 
	    		 	$this->email->message($isiemail); 
	    		 	// Tampilkan pesan sukses atau error 
	    		 	if ($this->email->send()) 
	    		 		{ 
	    		 			$pesan = '<div class="alert alert-success alert-dismissible fade show" role="alert"> 
	    		 			<h4 class="alert-heading">Berhasil...</h4><hr> Silahkan Cek Email anda, kami mengirimkan Link Ganti Password 
	    		 			<button type="button" class="close" data-dismiss="alert" aria-label="Close"> 
	    		 			<span aria-hidden="true">&times;
	    		 			</span> </button> </div>'; 
	    		 			$this->session->set_flashdata('pesan', $pesan); 
	    		 			redirect('login/lupapassword', 'refresh'); 
	    		 		} else { 
	    		 			$pesan = '<div class="alert alert-danger alert-dismissible fade show" role="alert"> 
	    		 			<h4 class="alert-heading">Error</h4><hr> 
	    		 			Maaf e-mail tidak terkirim, pastikan sudah terkoneksi internet 
	    		 			<button type="button" class="close" data-dismiss="alert" aria-label="Close"> 
	    		 			<span aria-hidden="true">&times;
	    		 			</span> </button> </div>'; 
	    		 			$this->session->set_flashdata('pesan', $pesan); 
	    		 			redirect('login/lupapassword', 'refresh'); 
	    		 		} 
	    		 	} else { 
	    		 		$pesan = array( 
	    		 			'pesan' => '<div class="alert alert-danger"> 
	    		 			Maaf E-Mail yang anda input tidak terdaftar di tabel registrasi 
	    		 			</div>' 
	    		 			); 
	    		 		$this->session->set_flashdata($pesan); 
	    		 		redirect('login/lupapassword', 'refresh'); 
	    		 	} 
	    		 } else { 
	    		 	$pesan = array( 
	    		 		'pesan' => '<div class="alert alert-danger"> ' . validation_errors() . ' </div>' ); 
	    		 	$this->session->set_flashdata($pesan); 
	    		 	redirect('login/lupapassword', 'refresh'); 
	    		} 
	    	}
	    	function formpasswordbaru()
	    	{
	    		$this->load->library('encryption');
	    		$iduser =$this->encryption->decrypt(base64_decode(urldecode($this->uri->segment(3))));
	    		$data =[
	    		'iduser'=>$iduser
	    		];
	    		$view = array(
	    			'isi' => $this->load->view('login/formresetpassword',$data,true)
	    			);
	    		$this->parser->parse('reg/viewform',$view);
	    	}
	    	function updatepassword() 
	    	{ 
	    		$iduser = $this->input->post('iduser', true); 
	    		$passbaru = $this->input->post('passbaru', true); 
	    		$ulangipass = $this->input->post('ulangipassbaru', true); 
	    		$this->load->library(array(
	    			'encryption', 'form_validation')
	    		); 
	    		$enkripsi_iduser = urlencode(base64_encode($this->encryption->encrypt($iduser))); 
	    		$this->form_validation->set_rules('passbaru', 'Inputan Password Baru', 'trim|required', array( 
	    			'required' => '%s tidak boleh kosong' )
	    		); 
	    		$this->form_validation->set_rules('ulangipassbaru', 'Inputan Ulangi Password Baru', 'trim|required|matches[passbaru]', array( 
	    			'required' => '%s tidak boleh kosong', 
	    			'matches' => '%s harus sama dengan Inputan Password Baru' )
	    		); 
	    		if ($this->form_validation->run() == TRUE) 
	    			{ 
	    				$hash_passwordbaru = password_hash($passbaru, PASSWORD_BCRYPT); 
	    				$dataupdate = array( 'regpass1710015' => $hash_passwordbaru ); 
	    				$this->db->where('reguserid1710015', $iduser); 
	    				$this->db->update('reg1710015', $dataupdate); 
	    				$pesan = '<div class="alert alert-success alert-dismissible fade show" role="alert"> 
	    				<h4 class="alert-heading">Berhasil</h4>
	    				<hr> 
	    				Password anda berhasil di Update, silahkan login kembali 
	    				<button type="button" class="close" data-dismiss="alert" aria-label="Close"> 
	    				<span aria-hidden="true">&times;
	    				</span> </button> </div>'; 
	    				$this->session->set_flashdata('pesan', $pesan); 
	    				redirect('login/index/', 'refresh'); 
	    			} else { 
	    				$pesan = '<div class="alert alert-danger alert-dismissible fade show" role="alert"> 
	    				<h4 class="alert-heading">Error</h4><hr> ' . validation_errors() . ' 
	    				<button type="button" class="close" data-dismiss="alert" aria-label="Close"> 
	    				<span aria-hidden="true">&times;
	    				</span> </button> </div>'; 
	    				$this->session->set_flashdata('pesan', $pesan); 
	    				redirect('login/formpasswordbaru/' . $enkripsi_iduser, 'refresh'); 
	    			} 
	    		}

}

?>