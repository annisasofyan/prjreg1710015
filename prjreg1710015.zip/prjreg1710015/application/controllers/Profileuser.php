<?php 
class profileuser extends CI_Controller 
{ 
	public function __construct() 
	{ parent::__construct(); 
		if ($this->session->userdata('login') == TRUE && $this->session->userdata('idlevel') == 2) 
			{ 
				return true;
				 } else { 
				 	redirect('login/index', 'refresh');
			} 
	} 
	public function index() 
	{ 
		$iduser = $this->session->userdata('iduser'); 
		$query = $this->db->query("SELECT * FROM reg1710015 WHERE reguserid1710015='$iduser'"); 
		$baris = $query->row_array(); 
		$data = array( 'iduser' => $iduser,
			'namauser' => $baris['regnama1710015'], 
			'jenkel' => $baris['regjk1710015'], 
			'tempatlahir' => $baris['regtmplahir1710015'], 
			'tanggallahir' => $baris['regtgllahir1710015'], 
			'foto' => $baris['regfoto1710015'], 
			'alamat' => $baris['regalamat1710015'], 
			'email' => $baris['regemail1710015'] ); 
		$parser = array( 
			'menu' => $this->load->view('home/menu', '', true), 
			'judul' => 'profile User', 
			'isi' => $this->load->view('profile/viewuser', $data, true), 
			); 
		$this->parser->parse('home/layout', $parser); 
	}
	function formupdate()
	{
		$iduser = $this->uri->segment(3);
		$data = array(
			'iduser' => $iduser
		);
		$parser = array(
			'menu' =>$this->load->view('home/menu','',true),
			'judul' =>'Update Profile User',
			'isi' =>$this->load->view('profile/formupdate',$data,true),
			);
		$this->parser->parse('home/layout',$parser);
	}
	function updatedata() 
	{ 
		$iduser = $this->session->userdata('iduser'); 
		$namauser = $this->input->post('namauser', true); 
		$tmplahir = $this->input->post('tmplahir', true); 
		$tgllahir = $this->input->post('tgllahir', true); 
		$jenkel = $this->input->post('jenkel', true); 
		$alamat = $this->input->post('alamat', true); 
		if 
			($_FILES['uploadfoto']['name'] == NULL) 
				{ 
					$dataupdate = array( 
						'regnama1710015' => $namauser, 
						'regjk1710015' => $jenkel, 
						'regtmplahir1710015' => $tmplahir, 
						'regtgllahir1710015' => $tgllahir, 
						'regalamat1710015' => $alamat 
						); 
					$this->db->where('reguserid1710015', $iduser); 
					$this->db->update('reg1710015', $dataupdate); 
				} else { 
					$config = array( 
						'upload_path' => './fotouser/', 
						'allowed_types' => 'jpg|jpeg|png', 
						'max_size' => 0, 
						'max_width' => 0, 
						'max_height' => 0, 
						'file_name' => strtolower($iduser) 
						); 
					$this->load->library('upload'); 
					$this->upload->initialize($config); 
					if 
						(!$this->upload->do_upload('uploadfoto')) 
					{ 
						echo $this->upload->display_errors(); 
					} else { 
						$ambildata = $this->db->get_where('reg1710015', array(
							'reguserid1710015' => $iduser)
						); 
						$r = $ambildata->row_array(); 
						$pathfotolama = $r['regfoto1710015']; 
						@unlink($pathfotolama); 
						$media = $this->upload->data(); 
						$pathfotobaru = './fotouser/' . $media['file_name']; 
						$dataupdate = array( 
							'regnama1710015' => $namauser, 
							'regjk1710015' => $jenkel, 
							'regtmplahir1710015' => $tmplahir, 
							'regtgllahir1710015' => $tgllahir, 
							'regalamat1710015' => $alamat, 
							'regfoto1710015' => $pathfotobaru 
							);
						$this->db->where('reguserid1710015', $iduser); 
						$this->db->update('reg1710015', $dataupdate); 
					} 
				} 
				redirect('profileuser/index'); 
			}

}
?>