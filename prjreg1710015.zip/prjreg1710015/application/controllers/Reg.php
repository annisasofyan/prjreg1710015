<?php 
class Reg extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->library('encryption');
        $this->load->model('Modelreg','reg');
    }
    function index()
    {
        $view = array (
            'isi' => $this->load->view('reg/formregistrasi','',true)
        );
        $this->parser->parse('reg/viewform',$view);
    }
    function simpanreg()
    {
        $namauser = $this->input->post('namalengkap', true);
        $iduser = $this->input->post('iduser');
        $pass = $this->input->post('passuser', true);
        $ulangipass = $this->input->post('ulangipassuser', true);
        $email = $this->input->post('emailuser', true);

        $this->form_validation->set_rules('namalengkap','Nama Lengkap','trim|required', array(
            'required' => '%s tidak boleh kosong' 
        ));
        $this->form_validation->set_rules(
            'iduser','Id User', 'trim|required|is_unique[reg1710015.reguserid1710015]|is_unique[admin1710015.adminid1710015]', array(
                'required' => '%s tidak boleh kosong',
                'is_unique' => '%s sudah ada dalam database, coba lagi'
            ));
        $this->form_validation->set_rules(
                'emailuser','Email', 'trim|required|is_unique[reg1710015.regemail1710015]', array(
                    'required' => '%s tidak boleh kosong',
                    'is_unique' => '%s sudah ada dalam database, coba lagi'
                ));
         $this->form_validation->set_rules('passuser','Password','trim|required', array(
                    'required' => '%s tidak boleh kosong' 
            ));
         $this->form_validation->set_rules('ulangipassuser','Ulangi Password','trim|required|matches[passuser]', array(
                'required' => '%s tidak boleh kosong',
                'matches' => '%s harus sama'
            ));
            if ($this->form_validation->run() == true){
                //konfigurasi email

            $config = array(
                'mailtype' => 'html',
                'charset' => 'utf-8',
                'protocol' => 'smtp',
                'smtp_host' => 'smtp.googlemail.com',
                'smtp_user' => 'annisa.sofyan30',
                'smtp_pass' => 'islahramadhan',
                'smtp_crypto' => 'ssl',
                'smtp_port' => 465,
                'crlf' => "\r\n",
                'newline' => "\r\n"
            );
            $this->load->library('email', $config);
            //EMAIL DAN NAMA PENGIRIM
            $this->email->from('no-reply@annisa.com','Annisa');
            //EMAIL PENERIMA
            $this->email->to($email);
            $this->email->subject('kirim email dengan SMTP Gmail CodeIgnitier | Annisa');
           
            $linkverifikasi_iduser = urlencode(base64_encode($this->encryption->encrypt($iduser)));
            $datauser = array(
                'namalengkap'  => $namauser,
                'iduser' =>$iduser,
                'linkverifikasi' => site_url() . '/reg/verifikasiemail/' .$linkverifikasi_iduser

            );
            $isiemail = $this->load->view('reg/isiemail', $datauser,true);
            $this->email->message($isiemail);

            if($this->email->send()){
                $enkripsi_password = password_hash($pass, PASSWORD_BCRYPT);
                $simpanregistrasi = $this->reg->simpandata($namauser,$iduser,$enkripsi_password,$email);
                
                if($simpanregistrasi) {
                    $pesan = '<div class ="alert alert-success alert dismissible fade show" role="alert">
                    <h4 class = "alert-heading">berhasil....</h4><hr>
                    registrasi anda berhasil, silahkan cek email untukverifikasi registrasi anda.
                    <button typr="button " class ="close" data dismiss="alert " aria-label="close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    </div>';
                    $this->session->set_flashdata('validasi',$pesan);
                    redirect('reg/index','refresh');

                }
            }else{
                $pesan = '<div class ="alert alert-danger alert dismissible fade show" role="alert">
                <h4 class = "alert-heading">error</h4><hr>
               maaf email tidak terkirim , pastikan sudah terkoneksi internet.
                <button typr="button " class ="close" data dismiss="alert " aria-label="close">
                <span aria-hidden="true">&times;</span>
                </button>
                </div>';
                $this->session->set_flashdata('validasi',$pesan);
                // redirect('reg/index','refresh');
                echo "EROR";
            }
            }else{
                $pesan = '<div class ="alert alert-success alert dismissible fade show" role="alert">
                <h4 class = "alert-heading">error</h4><hr>
               '. validation_errors() .'
                <button typr="button " class ="close" data dismiss="alert " aria-label="close">
                <span aria-hidden="true">&times;</span>
                </button>
                </div>';
                $this->session->set_flashdata('validasi',$pesan);
                redirect('reg/index','refresh');
            }
        
        }
        function verifikasiemail(){
            $iduser_enkripsi = $this->uri->segment(3);
            $iduser_dekrip = $this->encryption->decrypt(base64_decode(urldecode($iduser_enkripsi)));

            //lakukan cek data pada tabel reg
            $querycekdata = $this->reg->cekregistrasiuser($iduser_dekrip);

            if ($querycekdata->num_rows() > 0 ) {
                //lakukan update status menjadi aktif pada tabel registrasi

                $queryupdate = $this->reg->updatestatus($iduser_dekrip);

                if ($queryupdate) {
                    $pesan = '<div class ="alert alert-success alert dismissible fade show" role="alert">
                    <h4 class = "alert-heading">Selamat....!</h4><hr>
                    registrasi anda berhasil, silahkan login dengan id user dan password yang telah anda daftarkansebelumnya.
                    <button typr="button " class ="close" data dismiss="alert " aria-label="close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    </div>';
                    $this->session->set_flashdata('pesan',$pesan);
                    redirect('login/index','refresh');

                }
            } else {

                exit ('maaf data tidak registrasi user tidak di temukan');
            }
        }

}
?>