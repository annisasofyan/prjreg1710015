<?php
 class Modeldaftaruser extends CI_Model
  	{
   		function datauserregistrasi() 
   		{
   			return $this->db->get('reg1710015'); 
		}
		function ambildatauser($id) 
		{ 
			return $this->db->get_where('reg1710015', array('regid1710015' => $id)); 
		}
		function updatestatususer($id,$status)
		{
			if ($status == 1){
				$dataupdate = array(
					'regstatus1710015' => 0
					);
			}else{
				$dataupdate =array(
					'regstatus1710015'=>1
					);
			}
			$this->db->where('regid1710015' , $id);
			return $this->db->update('reg1710015',$dataupdate);
		}
	}
?>