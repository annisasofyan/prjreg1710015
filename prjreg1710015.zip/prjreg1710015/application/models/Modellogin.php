<?php 
class Modellogin extends CI_model
{
	function cekuseradmin($iduser)
	{
		return $this->db->get_where('admin1710015', array('adminid1710015' => $iduser)); 
	}
	function cekuserregistrasi($iduser)
	{
		return $this->db->get_where('reg1710015', array('reguserid1710015' => $iduser)); 
	}
}

?>