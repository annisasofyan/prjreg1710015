<?php 
class Modelreg extends CI_Model
{
    function simpandata($namauser,$iduser,$enkripsi_password,$email){
        //$date=date('Y-m-d');
        $data = array(
            'regtgl1710015' => date('Y-m-d'),
            'regnama1710015' => $namauser,
            'regemail1710015' => $email,
            'reguserid1710015' => $iduser,
            'regpass1710015' => $enkripsi_password
        );
        return $this->db->insert('reg1710015',$data);
        //return $this->db->query("INSERT INTO `dbregistrasi1710015`.`reg1710015` (`regtgl1710015`, `regnama1710015`) VALUES ('$date', 'COBA');");
    }
    function cekregistrasiuser($iduser_dekrip) {
        return $this->db->get_where('reg1710015', array('reguserid1710015 => $iduser_dekrip'));
    }
    
        function updatestatus($iduser_dekrip) {
        $data = array(
            'regstatus1710015' => 1,    
            'reglevelid1710015' => 2
            );
        $this->db->where('reguserid1710015',$iduser_dekrip);
        return $this->db->update('reg1710015',$data);
    }
        
}   


?>