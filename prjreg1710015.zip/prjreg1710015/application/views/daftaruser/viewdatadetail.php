<div class="row"> 
	<div class="col-lg-12"> 
		<div class="card shadow mb-4"> 
			<div class="card-header py-3"> 
				<h6 class="m-0 font-weight-bold text-primary"> 
					<?php echo anchor('daftaruser/index', 'Kembali', array('class' => 'btn btn-outline-warning')) ?> 
				</h6> 
			</div> 
			<div class="card-body"> 
				<table class="table table-striped"> 
					<tr> 
						<td style="width:25%;">Nama User</td> 
						<td style="width:2%;">:</td> 
						<td> 
							<?php echo $nama; ?> 
						</td> 
					</tr> 
					<tr> 
						<td>Tgl.Registrasi</td> 
						<td>:</td> 
						<td> 
							<?php echo $tglreg; ?> 
						</td> 
					</tr> 
					<tr> 
						<td>E-Mail</td> 
						<td>:</td> 
						<td> 
							<?php echo $email; ?> 
						</td> 
					</tr> 
					<tr> 
						<td>Jenis Kelamin</td> 
						<td>:</td> 
						<td> 
							<?php echo $jk; ?> 
						</td> 
					</tr> 
					<tr> 
						<td>Tempat/Tgl.Lahir</td> 
						<td>:</td> 
						<td> 
							<?php echo $ttl; ?> 
						</td> 
					</tr> 
					<tr> 
						<td>Alamat</td> 
						<td>:</td> 
						<td> 
							<?php echo $alamat; ?> 
						</td> 
					</tr> 
					<tr> 
						<td>Foto</td> 
						<td>:</td> 
						<td> 
							<img src="<?php echo base_url($foto); ?>" alt="Foto User"> 
						</td> 
					</tr>
					<tr> 
						<td>Status User</td> 
						<td>:</td> 
						<td> 
							<?php 
							if ($status == 1) { 
								echo '<span class="badge badge-success">Aktif</span>'; 
							} else { 
								echo '<span class="badge badge-danger">Tidak Aktif</span>'; 
							} 
							?> 
						</td> 
					</tr> 
					<tr> 
						<td colspan="3"> 
							<button type="button" class="btn btn-info" 
							onclick="updatestatususer(<?php echo $idreg; ?>)"> 
							Ubah Status User ? 

						</button> 
						<script>
						function updatestatususer(id) {
							pesan = confirm ('Yakin Status User di Update ?');
							if (pesan)
								window.location.href = ("<?php echo site_url('daftaruser/updatestatus/') ?>" + id);
							else return false;
						}
						</script>
					</td> 
				</tr> 
			</table> 
		</div> 
	</div> 
</div> 
</div>