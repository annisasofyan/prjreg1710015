<div class="row"> 
	<div class="col-lg-12"> 
		<div class="card shadow mb-4"> 
			<div class="card-header py-3"> 
				<h6 class="m-0 font-weight-bold text-info"> 
					Form Ganti Password 
				</h6> 
			</div> 
			<div class="card-body"> 
				<?php echo form_open('gantipassword/update') ?> 
				<div class="row"> 
					<div class="col"> 
						<?php echo $this->session->flashdata('pesan'); ?> 
					</div> 
				</div> 
				<div class="row form-group"> 
					<label class="col-md-3 col-control-label" for="passlama"> Password Lama 
					</label> 
					<div class="col-md-9"> 
						<input type="password" name="passlama" id="passlama" class="form-control"> 
					</div> 
				</div> 
				<div class="row form-group"> 
					<label class="col-md-3 col-control-label" for="passbaru"> Password Baru 
					</label> 
					<div class="col-md-9"> 
						<input type="password" name="passbaru" id="passbaru" class="form-control"> 
					</div> 
				</div> 
				<div class="row form-group"> 
					<label class="col-md-3 col-control-label" for="ulangipassbaru"> Ulangi Password Baru 
					</label> 
					<div class="col-md-9"> 
						<input type="password" name="ulangipassbaru" id="ulangipassbaru" class="form-control"> 
					</div> 
				</div> 
				<div class="row form-group"> 
					<div class="col-md-9 text-center"> 
						<button type="submit" class="btn btn-primary"> Update Password 
						</button> 
					</div> 
				</div> 
				<?php echo form_close() ?> 
			</div> 
		</div> 
	</div>
	