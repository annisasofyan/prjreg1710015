<hr class="sidebar-divider my-0">
<li class="nav-item <?php if ($this->uri->segment(1) == 'home') echo 'active'; ?> ">
	<a class="nav-link" href="<?php echo site_url('home/index')?>">
		<i class="fas fa-fw fa-tachometer-alt"></i>
		<span>Beranda</span>
	</a>
</li>
<?php
$level =$this->session->userdata('idlevel');
if ($level==1) {
	 ?>
	 <li class="nav-item<?php if($this->uri->segment(1) == 'daftaruser') echo 'active';?>">
	 	<a class="nav-link" href="<?php echo site_url('daftaruser/index')?>">
	 		<i class="fas fa-fw fa-users"></i>
	 		<span>Daftar User</span>
	</a>
</li>

<li class="nav-item <?php if ($this->uri->segment(1) == 'kategori') echo 'active'; ?>"> 
	<a class="nav-link" href="<?php echo site_url('kategori/index') ?>"> 
		<i class="fas fa-fw fa-file"></i> 
		<span>Kategori Produk</span> 
	</a> 
</li> 
<li class="nav-item <?php if ($this->uri->segment(1) == 'produk') echo 'active'; ?>"> 
	<a class="nav-link" href="<?php echo site_url('produk/index') ?>"> 
		<i class="fas fa-fw fa-gift">
		</i> 
		<span>Produk</span> 
	</a> 
</li>

<?php
}
?>
<?php
$level =$this->session->userdata('idlevel');
if ($level==2) {
	 ?>
	 <li class="nav-item<?php if($this->uri->segment(1) == 'profiluser') echo 'active';?>">
	 	<a class="nav-link" href="<?php echo site_url('profileuser/index')?>">
	 		<i class="fas fa-fw fa-portrait"></i>
	 		<span>Profile User</span>
	</a>
</li>
<?php
}
?>
 <li class="nav-item<?php if($this->uri->segment(1) == 'gantipassword') echo 'active';?>">
	 	<a class="nav-link" href="<?php echo site_url('gantipassword/index')?>">
	 		<i class="fas fa-fw fa-cog"></i>
	 		<span>Ganti Password</span>
	</a>
</li>