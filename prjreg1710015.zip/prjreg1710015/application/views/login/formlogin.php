<div class = "row justify-content-center">
<div class ="col-lg-12">
    <div class ="p-5">
        <div class ="text-center">
        	 <h1 class ="h4 text-gray-900 mb-4">silahkan login !</h1>
        </div>
        <p>
        	 <?php echo form_open('login/cekuser', array('class' =>'user'))?>
            <?php echo $this->session->flashdata('pesan') ?>
              <div class ="form-group row justify-content-center">
      			  <div class ="col-lg-6">
            		<input type ="text" name="iduser" class="form-control form-control-user" placeholder="isikan id user anda" autofocus autocomplete="off">
       				</div>
   			 </div>
   			  <div class ="form-group row justify-content-center">
       			 <div class ="col-lg-6">
           		 <input type ="password" name="passuser" class="form-control form-control-user" placeholder="isikan password anda" autocomplete="off">
        </div>
    </div>
    		 <div class ="form-group row justify-content-center">
        <div class ="col-lg-6">
           <button type="submit" class="btn btn-block btn-user btn-success ">
            <i class="fa fw fa-sign-in-alt"></i>login
            </button>
        </div>
    </div>
    		 <?php echo form_close();?>
        </p>
        <p>
        	 <div class ="form-group row justify-content-center">
       			 <div class ="col-lg-6">
           		 <?php echo anchor('login/lupapassword', 'Lupa Password ?', array('class' =>'btn btn-block btn-user btn-info')) ?>
        </div>
    </div>
    	 <div class ="form-group row justify-content-center">
       			 <div class ="col-lg-6">
           		 <?php echo anchor('reg/index', 'Ingin Registrasi ?', array('class' =>'btn btn-block btn-user btn-primary')) ?>
        </div>
    </div>
        </p>
     </div>
</div>
</div>