<div class="row justify-content-center"> 
	<div class="col-lg-12"> 
		<div class="p-5"> 
			<div class="text-center"> 
				<h1 class="h4 text-gray-900 mb-4">
					Silahkan Isi Password Baru Anda
				</h1> 
			</div> 
			<hr> 
			<p> 
				<?php echo form_open('login/updatepassword', array('class' => 'user')) ?> 
				<?php echo $this->session->flashdata('pesan'); ?> 
				<div class="form-group row justify-content-center"> 
					<div class="col-lg-6"> 
						<input type="hidden" name="iduser" value="<?php echo $iduser; ?>"> 
						<input type="password" name="passbaru" class="form-control form-control-user" 
						placeholder="Isikan Password Baru Anda" autofocus autocomplete="off"> 
					</div> 
				</div> 
				<div class="form-group row justify-content-center"> 
					<div class="col-lg-6"> 
						<input type="password" name="ulangipassbaru" class="form-control form-control-user" 
						placeholder="Ulangi Password Baru Anda" autocomplete="off"> 
					</div> 
				</div> 
				<div class="form-group row justify-content-center"> 
					<div class="col-lg-6"> 
						<button type="submit" class="btn btn-user btn-block btn-outline-success"> 
							Update Your Password 
						</button> 
					</div> 
				</div> 
				<?php echo form_close() ?> 
			</p> 
		</div> 
	</div> 
</div>