<h1 <?php echo $namalengkap ?> </h1>
<hr>
Silahkan Klik Berikut Untuk Mereset Password Anda....
<br>
<a href="<?php echo $linkverifikasi; ?>" target="_blank">Klik Disini</a>
