<div 
class="row"> 
<div class="col-lg-12"> 
	<div class="card shadow mb-4"> 
		<div class="card-header py-3"> 
			<h6 class="m-0 font-weight-bold text-primary"> Silahkan Isi Form Berikut </h6> 
		</div> 
		<div class="card-body"> 
			<?php echo form_open_multipart('profileuser/updatedata'); ?> 
			<div class="row form-group"> 
				<label class="col-md-3 col-control-label" for="namauser"> Nama User </label>
					<div class="col-md-9"> 
						<input type="text" class="form-control" name="namauser" id="namauser"> 
					</div> 
				</div> 
				<div class="row form-group"> 
					<label class="col-md-3 col-control-label" for="ttl"> Tempat/Tgl.Lahir </label> 
					<div class="col-md-3"> 
						<input type="text" class="form-control" name="tmplahir" id="ttl"> 
					</div> 
					<div class="col-md-3"> 
						<input type="date" class="form-control" name="tgllahir"> 
					</div> 
				</div> 
				<div class="row form-group"> 
					<label class="col-md-3 col-control-label" for="jenkel"> Jenis Kelamin </label> 
					<div class="col-md-4"> 
						<select class="form-control" name="jenkel" id="jenkel"> 
							<option selected value="">Pilih</option> 
							<option value="L">Laki-Laki</option> 
							<option value="P">Perempuan</option> 
						</select> 
					</div> 
				</div> 
				<div class="row form-group"> 
					<label class="col-md-3 col-control-label" for="alamat"> Alamat </label> 
					<div class="col-md-9"> 
						<textarea name="alamat" id="alamat" cols="30" rows="5" class="form-control"></textarea> 
					</div> 
				</div> 
				<div class="row form-group"> 
					<label class="col-md-3 col-control-label" for="alamat"> Upload Foto </label> 
					<div class="col-md-9"> 
						<input type="file" name="uploadfoto"> 
					</div> 
				</div> 
				<div class="row form-group justify-content-center"> 
					<div class="col-md-4"> 
						<input type="submit" value="Simpan" class="btn btn-success"> 
					</div> 
				</div> 
				<?php echo form_close(); ?> 
			</div> 
		</div> 
	</div> 
</div>