<script> 
function updateprofile(iduser) 
{ 
	window.location.href = ("<?php echo site_url('profileuser/formupdate/') ?>" + iduser); 
} 
</script> 
<div class="row"> 
	<div class="col-lg-12"> 
		<div class="card shadow mb-4"> 
			<div class="card-header py-3"> 
				<h6 class="m-0 font-weight-bold text-primary"> 
					<button type="button" class="btn btn-outline-info" 
					onclick="updateprofile('<?php echo $iduser ?>')"> 
					Update profile 
				</button> 
			</h6> 
		</div> 
		<div class="card-body"> 
			<table class="table table-striped"> 
				<tr> 
					<td style="width: 25%;">Nama Lengkap</td> 
					<td style="width: 2%;">:</td> 
					<td><?php echo $namauser; ?></td> 
				</tr> 
				<tr> 
					<td>Jenis Kelamin</td> 
					<td>:</td> 
					<td><?php echo $jenkel ?></td> 
				</tr> 
				<tr> 
					<td>Tempat/Tgl.Lahir</td> 
					<td>:</td> 
					<td><?php echo $tempatlahir . '/' . $tanggallahir ?></td> 
				</tr> 
				<tr> 
					<td>Alamat</td> 
					<td>:</td> 
					<td><?php echo $alamat ?></td> 
				</tr> 
				<tr> 
					<td>E-Mail</td> 
					<td>:</td> 
					<td><?php echo $email ?></td> 
				</tr> 
				<tr> 
					<td>Foto</td> 
					<td>:</td> <td>
					<img src="<?php echo base_url($foto) ?>" style="width:100%;" alt="Foto User"> 
				</td> 
			</tr> 
		</table> 
	</div> 
</div> 
</div> 
</div>