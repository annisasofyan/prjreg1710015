<div class = "row justify-content-center">
<div class ="col-lg-12">
    <div class ="p-5">
        <div class ="text-center">
            <h1 class ="h4 text-gray-900 mb-4">silahkan lakukan registrasi !</h1>
        </div>
        <?php echo form_open('reg/simpanreg', array('class' =>'user'))?>
            <?php echo $this->session->flashdata('validasi') ?>
        <div class ="form-group row justify-content-center">
        <div class ="col-lg-6">
            <input type ="text" name="namalengkap" class="form-control form-control-user" placeholder="isikan nama lengkap anda" autofocus autocomplete="off">
        </div>
    </div>
    <div class ="form-group row justify-content-center">
        <div class ="col-lg-6">
            <input type ="text" name="iduser" class="form-control form-control-user" placeholder="isikan id user yang dinginkan,ID user tidak boleh sama" autocomplete="off">
        </div>
    </div>
    <div class ="form-group row justify-content-center">
        <div class ="col-lg-6">
            <input type ="password" name="passuser" class="form-control form-control-user" placeholder="isikan password anda" autocomplete="off">
        </div>
    </div>
    <div class ="form-group row justify-content-center">
        <div class ="col-lg-6">
            <input type ="password" name="ulangipassuser" class="form-control form-control-user" placeholder="ulangi, isikan password anda" autocomplete="off">
        </div>
    </div>
    <div class ="form-group row justify-content-center">
        <div class ="col-lg-6">
            <input type ="email" name="emailuser" class="form-control form-control-user" placeholder="isikan email yang valid atau aktif" autocomplete="off">
        </div>
    </div>
    
    <div class ="form-group row justify-content-center">
        <div class ="col-lg-6">
          <div class ="alert alert-info">
          link verifikasi dariregistrsi anda akan dikirimkan ke-email anda, jadi pastikan email yang anda inputkan valid
        </div>
    </div>
    </div>
    <div class ="form-group row justify-content-center">
        <div class ="col-lg-6">
           <button type="submit" class="btn btn-block btn-user btn-success ">
            <i class="fa fa-save"></i>registrasi
            </button>
        </div>
    </div>
        <?php echo form_close();?>

        <p> <p> <div class="form-group row justify-content-center">
         <div class="col-lg-6"> <?php echo anchor('login/index', 'Login ?', array('class' => 'btn btn-block btn-user btn-primary')) ?>
          </div> 
      </div>
            <div class="form-group row justify-content-center">
           <div class="col-lg-6">
            <?php echo anchor('login/lupapassword', 'Lupa Password ?', array('class' => 'btn btn-block btn-user btn-info')) ?>
         </div>
          </div>
        </div>
    </div>
</div>