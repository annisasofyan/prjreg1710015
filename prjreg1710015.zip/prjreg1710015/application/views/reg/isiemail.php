<h1>halo<?php echo $namalengkap ?></h1>
<hr>
terima kasih sudah mendaftar,klik link berikut ini untuk verifikasi email anda.....!
<br>
<?php echo $linkverifikasi; ?>